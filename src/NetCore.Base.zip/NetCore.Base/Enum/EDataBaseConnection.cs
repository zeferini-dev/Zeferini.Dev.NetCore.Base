﻿namespace NetCore.Base.Enum
{
    public enum EDataBaseConnection
    {
        ID_DB_SQL_SERVER = 1,
        ID_DB_REDIS_IUD  = 2,
        ID_DB_REDIS_GET  = 3,
        ID_DB_MYSQL      = 4,
        ID_DB_POSTGRESQL = 5,
        ID_DB_MONGODB    = 6,
        ID_DB_DYNAMODB   = 7,
    }
}
