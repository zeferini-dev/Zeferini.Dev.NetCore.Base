﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCore.Base.Enum
{
    public enum EAction
    {
        GET = 0,INSERT = 1, UPDATE = 2,DELETE = 3,
    }
}
