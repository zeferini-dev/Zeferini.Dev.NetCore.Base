﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetCore.Base.Enum
{
    public enum EGenero
    {
        Feminino = 0, Masculino = 1, PrefiroNaoInformar = 2,
    }
}
