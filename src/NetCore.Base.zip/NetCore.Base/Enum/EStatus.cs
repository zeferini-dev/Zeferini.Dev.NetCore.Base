﻿namespace NetCore.Base.Enum
{
    public enum EStatus
    {
        AUSENTE  = -2,
        EXCLUIDO = -1,
        INATIVO  =  0,
        ATIVO    =  1
    }
}
