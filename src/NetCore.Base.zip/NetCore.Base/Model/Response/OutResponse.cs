﻿namespace NetCore.Base.Model.Response
{
    public class AuthorizationOutResponse : ResponseBase { }
    public class LogOutResponse : ResponseBase { }

    public class GrupoOutResponse : ResponseBase { }
    public class EmpresaOutResponse : ResponseBase { }
    public class FilialOutResponse : ResponseBase { }
    public class DepartamentoOutResponse : ResponseBase { }
    public class PessoaOutResponse : ResponseBase { }
    public class UsuarioOutResponse : ResponseBase { }
}
